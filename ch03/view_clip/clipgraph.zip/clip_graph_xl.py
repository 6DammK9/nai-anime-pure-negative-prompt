

import numpy as np
import torch

from diffusers import (
    StableDiffusionPipeline,
    StableDiffusionXLPipeline,
)
import json
import os
import matplotlib.pyplot as plt
from sklearn.manifold import TSNE
from sklearn.decomposition import PCA
import umap
import argparse
import plotly.graph_objects as go


def config_to_category_colors(embed_groupings):
    def generate_colors(num_colors):
        cmap = plt.get_cmap('magma')  # 'viridis', 'plasma', 'inferno', 'magma' are good alternatives
        colors = [cmap(i) for i in np.linspace(0, 1, num_colors)]
        hex_colors = ['#%02x%02x%02x' % (int(rgb[0]*255), int(rgb[1]*255), int(rgb[2]*255)) for rgb in colors]
        return hex_colors

    with open(embed_groupings, 'r') as file:
        named_cluster_dict = json.load(file)

    colors = generate_colors(len(named_cluster_dict))
    category_colors = {category: colors[idx] for idx, category in enumerate(named_cluster_dict)}

    id_to_category = {}
    for category, ids in named_cluster_dict.items():
        for id in ids:
            id_to_category[id] = category
            
    return category_colors, id_to_category

def plot_embeddings(embeddings_reduced, text_dict, id_to_category, category_colors):
    fig = go.Figure()
    
    for i, id in enumerate(text_dict):
        category = id_to_category[str(id)]
        color = category_colors[category]
        text = text_dict[str(id)]

        fig.add_trace(go.Scatter(
            x=[embeddings_reduced[i, 0]],
            y=[embeddings_reduced[i, 1]],
            mode='markers',
            marker=dict(symbol='circle', size=10, color=color),
            name=text,
            hoverinfo='text'
        ))

    fig.update_layout(
        title="Visualization of Embeddings",
        xaxis_title="Component 1",
        yaxis_title="Component 2",
        legend_title="Labels"
    )

    fig.show()

def compute_embedding(text, tokenizer, text_encoder, device):
    # Tokenize the current text
    embeds = tokenizer(
        text,
        padding="max_length",
        max_length=tokenizer.model_max_length,
        truncation=True,
        return_tensors="pt",
    )
    
    # Encode the tokenized text
    prompt_embeds = text_encoder(
        embeds.input_ids.to(device),
        output_hidden_states=True,
    )
    
    # Select specific hidden layers
    clip_skip = 2
    prompt_embeds = prompt_embeds.hidden_states[-clip_skip]

    # Reshape and normalize embeddings
    bs_embed, seq_len, _ = prompt_embeds.shape
    prompt_embeds = prompt_embeds.view(bs_embed, seq_len, -1)
    prompt_embeds = prompt_embeds.view(bs_embed, -1)  # Stack the sequences onto embeddings
    prompt_embeds = prompt_embeds / prompt_embeds.norm(dim=1, keepdim=True)

    return prompt_embeds

def compute_all_embeddings(text_dict, small_tokenizer, small_text_encoder, device):
    all_prompt_embeds = []
    for id, text in text_dict.items():
        embedding = compute_embedding(text, small_tokenizer, small_text_encoder, device)
        all_prompt_embeds.append(embedding)
    
    if all_prompt_embeds:
        all_prompt_embeds = torch.cat(all_prompt_embeds, dim=0)
    
    return all_prompt_embeds

def process_texts(text_dict, clip_type, small_tokenizer, small_text_encoder, continue_run, save_dir, device):
    # Ensure the directory exists
    os.makedirs(save_dir, exist_ok=True)
    embeddings_file_path = os.path.join(save_dir, f'{clip_type}_embeddings.pt')

    if continue_run:
        try:
            # Attempt to load the pre-saved embeddings state dictionary
            all_prompt_embeds = torch.load(embeddings_file_path)
            print(f"Loaded embeddings from {embeddings_file_path}")
        except FileNotFoundError:
            print(f"No file found at {embeddings_file_path}, computing all embeddings.")
            all_prompt_embeds = compute_all_embeddings(text_dict, small_tokenizer, small_text_encoder, device)
            torch.save(all_prompt_embeds, embeddings_file_path)
            print(f"Saved new embeddings to {embeddings_file_path}")
    else:
        # Compute all embeddings since continue_run is False
        all_prompt_embeds = compute_all_embeddings(text_dict, small_tokenizer, small_text_encoder, device)
        torch.save(all_prompt_embeds, embeddings_file_path)
        print(f"Saved embeddings to {embeddings_file_path}")

    return all_prompt_embeds

def compute_cosine_similarities(embeds):
    batch_size = 100  # Adjust based on your system's memory capacity
    num_embeddings = embeds.shape[0]
    L_cosine_similarities = torch.zeros((num_embeddings, num_embeddings), device=embeds.device)

    for i in range(0, num_embeddings, batch_size):
        end_i = min(i + batch_size, num_embeddings)
        for j in range(0, num_embeddings, batch_size):
            end_j = min(j + batch_size, num_embeddings)
            batch_result = torch.mm(embeds[i:end_i], embeds[j:end_j].T)
            L_cosine_similarities[i:end_i, j:end_j] = batch_result
    
    return L_cosine_similarities

def batched_torch_distance_matrix(embeddings, distance_type='euclidean', batch_size=100):
    num_embeddings = embeddings.shape[0]
    dtype = embeddings.dtype
    device = embeddings.device
    if distance_type == 'euclidean':
        # Placeholder for the distance matrix
        distance_matrix = torch.zeros((num_embeddings, num_embeddings), dtype=dtype, device=device)

        # Batch computation
        for i in range(0, num_embeddings, batch_size):
            end_i = min(i + batch_size, num_embeddings)
            emb_i = embeddings[i:end_i]
            for j in range(0, num_embeddings, batch_size):
                end_j = min(j + batch_size, num_embeddings)
                emb_j = embeddings[j:end_j]
                
                # Compute the pairwise Euclidean distance
                diff = emb_i.unsqueeze(1) - emb_j.unsqueeze(0)
                distances = torch.sqrt(torch.sum(diff**2, dim=-1))
                distance_matrix[i:end_i, j:end_j] = distances

    elif distance_type == 'manhattan':
        # Placeholder for the distance matrix
        distance_matrix = torch.zeros((num_embeddings, num_embeddings), dtype=dtype, device=device)

        # Batch computation
        for i in range(0, num_embeddings, batch_size):
            end_i = min(i + batch_size, num_embeddings)
            emb_i = embeddings[i:end_i]
            for j in range(0, num_embeddings, batch_size):
                end_j = min(j + batch_size, num_embeddings)
                emb_j = embeddings[j:end_j]
                
                # Compute the pairwise Manhattan distance
                diff = torch.abs(emb_i.unsqueeze(1) - emb_j.unsqueeze(0))
                distances = torch.sum(diff, dim=-1)
                distance_matrix[i:end_i, j:end_j] = distances

    return distance_matrix

def compute_distances_sdxl(model_paths, text_dict, output_dir, device="cuda", continue_run=False):
    results = {
        "Cosine": {},
        "Euclidean": {},
        "Manhattan": {},
        "Embeddings_L": {},
        "Embeddings_G": {},
    }

    for model_path in model_paths:
        model_name = os.path.basename(model_path)
        pipeline = StableDiffusionXLPipeline.from_single_file(model_path, use_safetensors=True, torch_dtype=torch.float16)
        pipeline.to(device)
        tokenizer = pipeline.tokenizer_2
        text_encoder = pipeline.text_encoder_2

        small_tokenizer = pipeline.tokenizer
        small_text_encoder = pipeline.text_encoder
        
        # Directory to store embeddings
        save_dir = os.path.join(output_dir, 'embeddings', model_name)
        if continue_run:
            if not os.path.exists(save_dir):
                os.makedirs(save_dir)
        clip_type_L = 'L'
        
        all_L_prompt_embeds = process_texts(text_dict, clip_type_L, small_tokenizer, small_text_encoder, continue_run, save_dir, device)

        # # Directory to store embeddings
        # distance_dir = f'distances/{model_name}/'
        # if not os.path.exists(distance_dir):
        #     os.makedirs(distance_dir)

        # batch_size = 100  # Adjust based on your system's memory capacity
        
        # if continue_run:
        #     file_path1 = f'{distance_dir}cosine_similarity.pt'
        #     try:
        #         L_cosine_similarities = torch.load(file_path1)
        #         print("Loaded cosine similarities from file.")
        #     except FileNotFoundError:
        #         print("File not found. Computing cosine similarities...")
        #         L_cosine_similarities = compute_cosine_similarities(all_L_prompt_embeds)
        #         torch.save(L_cosine_similarities, file_path1)
        #         print("Cosine similarities computed and saved.")
        # else:
        #     print("Not continuing from file. Computing cosine similarities...")
        #     L_cosine_similarities = compute_cosine_similarities(all_L_prompt_embeds)
        #     torch.save(L_cosine_similarities, file_path1)
        #     print("Cosine similarities computed and saved.")
        # L_cosine_similarities.to('cpu')

        # if continue_run:
        #     file_path2 = f'{distance_dir}euclidean_distances.pt'
        #     try:
        #         L_euclidean_distances = torch.load(file_path2)
        #         print("Loaded L_euclidean_distances  from file.")
        #     except FileNotFoundError:
        #         print("File not found. Computing L_euclidean_distances ...")
        #         L_euclidean_distances = batched_torch_distance_matrix(all_L_prompt_embeds, 'euclidean', batch_size)
        #         torch.save(L_euclidean_distances, file_path2)
        #         print("Cosine  computed and saved.")
        # else:
        #     print("Not continuing from file. Computing L_euclidean_distances ...")
        #     L_euclidean_distances = batched_torch_distance_matrix(all_L_prompt_embeds, 'euclidean', batch_size)
        #     torch.save(L_euclidean_distances, file_path2)
        #     print("L_euclidean_distances  computed and saved.")
        # L_euclidean_distances.to('cpu')
        
        # if continue_run:
        #     file_path3 = f'{distance_dir}manhattan_distances.pt'
        #     try:
        #         L_manhattan_distances = torch.load(file_path3)
        #         print("Loaded L_manhattan_distances  from file.")
        #     except FileNotFoundError:
        #         print("File not found. Computing L_manhattan_distances ...")
        #         L_manhattan_distances = batched_torch_distance_matrix(all_L_prompt_embeds, 'euclidean', batch_size)
        #         torch.save(L_manhattan_distances, file_path3)
        #         print("Cosine  computed and saved.")
        # else:
        #     print("Not continuing from file. Computing L_manhattan_distances ...")
        #     L_manhattan_distances = batched_torch_distance_matrix(all_L_prompt_embeds, 'manhattan', batch_size)
        #     torch.save(L_manhattan_distances, file_path3)
        #     print("L_manhattan_distances  computed and saved.")

        # Directory to store embeddings
        clip_type_G = 'G'
        all_G_prompt_embeds = process_texts(text_dict, clip_type_G, tokenizer, text_encoder, args.continue_run, save_dir, device)

        # Store results
        model_name = os.path.basename(model_path)
        # index_labels = list(text_dict.values())
        # results["Cosine"][model_name] = pd.DataFrame(L_cosine_similarities.cpu().numpy(), index=index_labels, columns=index_labels)
        # results["Euclidean"][model_name] = pd.DataFrame(L_euclidean_distances, index=index_labels, columns=index_labels)
        # results["Manhattan"][model_name] = pd.DataFrame(L_manhattan_distances, index=index_labels, columns=index_labels)
        # results['Embeddings'][model_name] = all_L_prompt_embeds
        results['Embeddings_L'][model_name] = all_L_prompt_embeds
        results['Embeddings_G'][model_name] = all_G_prompt_embeds

    return results



def compute_distances_sd15(model_paths, text_dict, output_dir, device="cuda", continue_run=False):
    results = {
        "Cosine": {},
        "Euclidean": {},
        "Manhattan": {},
        "Embeddings_L": {},
        "Embeddings_G": {},
    }

    for model_path in model_paths:
        model_name = os.path.basename(model_path)
        pipeline = StableDiffusionPipeline.from_single_file(model_path, use_safetensors=True, torch_dtype=torch.float16)
        pipeline.to(device)

        small_tokenizer = pipeline.tokenizer
        small_text_encoder = pipeline.text_encoder
        
        # Directory to store embeddings
        save_dir = os.path.join(output_dir, 'embeddings', model_name)
        if continue_run:
            if not os.path.exists(save_dir):
                os.makedirs(save_dir)
        clip_type_L = 'L'
        
        all_L_prompt_embeds = process_texts(text_dict, clip_type_L, small_tokenizer, small_text_encoder, continue_run, save_dir, device)

        # # Directory to store embeddings
        # distance_dir = f'distances/{model_name}/'
        # if not os.path.exists(distance_dir):
        #     os.makedirs(distance_dir)

        # batch_size = 100  # Adjust based on your system's memory capacity
        
        # if continue_run:
        #     file_path1 = f'{distance_dir}cosine_similarity.pt'
        #     try:
        #         L_cosine_similarities = torch.load(file_path1)
        #         print("Loaded cosine similarities from file.")
        #     except FileNotFoundError:
        #         print("File not found. Computing cosine similarities...")
        #         L_cosine_similarities = compute_cosine_similarities(all_L_prompt_embeds)
        #         torch.save(L_cosine_similarities, file_path1)
        #         print("Cosine similarities computed and saved.")
        # else:
        #     print("Not continuing from file. Computing cosine similarities...")
        #     L_cosine_similarities = compute_cosine_similarities(all_L_prompt_embeds)
        #     torch.save(L_cosine_similarities, file_path1)
        #     print("Cosine similarities computed and saved.")
        # L_cosine_similarities.to('cpu')

        # if continue_run:
        #     file_path2 = f'{distance_dir}euclidean_distances.pt'
        #     try:
        #         L_euclidean_distances = torch.load(file_path2)
        #         print("Loaded L_euclidean_distances  from file.")
        #     except FileNotFoundError:
        #         print("File not found. Computing L_euclidean_distances ...")
        #         L_euclidean_distances = batched_torch_distance_matrix(all_L_prompt_embeds, 'euclidean', batch_size)
        #         torch.save(L_euclidean_distances, file_path2)
        #         print("Cosine  computed and saved.")
        # else:
        #     print("Not continuing from file. Computing L_euclidean_distances ...")
        #     L_euclidean_distances = batched_torch_distance_matrix(all_L_prompt_embeds, 'euclidean', batch_size)
        #     torch.save(L_euclidean_distances, file_path2)
        #     print("L_euclidean_distances  computed and saved.")
        # L_euclidean_distances.to('cpu')
        
        # if continue_run:
        #     file_path3 = f'{distance_dir}manhattan_distances.pt'
        #     try:
        #         L_manhattan_distances = torch.load(file_path3)
        #         print("Loaded L_manhattan_distances  from file.")
        #     except FileNotFoundError:
        #         print("File not found. Computing L_manhattan_distances ...")
        #         L_manhattan_distances = batched_torch_distance_matrix(all_L_prompt_embeds, 'euclidean', batch_size)
        #         torch.save(L_manhattan_distances, file_path3)
        #         print("Cosine  computed and saved.")
        # else:
        #     print("Not continuing from file. Computing L_manhattan_distances ...")
        #     L_manhattan_distances = batched_torch_distance_matrix(all_L_prompt_embeds, 'manhattan', batch_size)
        #     torch.save(L_manhattan_distances, file_path3)
        #     print("L_manhattan_distances  computed and saved.")

        # Store results
        model_name = os.path.basename(model_path)
        # index_labels = list(text_dict.values())
        # results["Cosine"][model_name] = pd.DataFrame(L_cosine_similarities.cpu().numpy(), index=index_labels, columns=index_labels)
        # results["Euclidean"][model_name] = pd.DataFrame(L_euclidean_distances, index=index_labels, columns=index_labels)
        # results["Manhattan"][model_name] = pd.DataFrame(L_manhattan_distances, index=index_labels, columns=index_labels)
        # results['Embeddings'][model_name] = all_L_prompt_embeds
        results['Embeddings_L'][model_name] = all_L_prompt_embeds

    return results

def compute_distances_sd15(model_paths, text_dict, output_dir, device="cuda", continue_run=False):
    results = {
        "Cosine": {},
        "Euclidean": {},
        "Manhattan": {},
        "Embeddings_L": {},
        "Embeddings_G": {},
    }

    for model_path in model_paths:
        model_name = os.path.basename(model_path)
        pipeline = StableDiffusionPipeline.from_single_file(model_path, use_safetensors=True, torch_dtype=torch.float16)
        pipeline.to(device)

        small_tokenizer = pipeline.tokenizer
        small_text_encoder = pipeline.text_encoder
        
        # Directory to store embeddings
        save_dir = os.path.join(output_dir, 'embeddings', model_name)
        if continue_run:
            if not os.path.exists(save_dir):
                os.makedirs(save_dir)
        clip_type_L = 'L'
        
        all_L_prompt_embeds = process_texts(text_dict, clip_type_L, small_tokenizer, small_text_encoder, continue_run, save_dir, device)

        # # Directory to store embeddings
        # distance_dir = f'distances/{model_name}/'
        # if not os.path.exists(distance_dir):
        #     os.makedirs(distance_dir)

        # batch_size = 100  # Adjust based on your system's memory capacity
        
        # if continue_run:
        #     file_path1 = f'{distance_dir}cosine_similarity.pt'
        #     try:
        #         L_cosine_similarities = torch.load(file_path1)
        #         print("Loaded cosine similarities from file.")
        #     except FileNotFoundError:
        #         print("File not found. Computing cosine similarities...")
        #         L_cosine_similarities = compute_cosine_similarities(all_L_prompt_embeds)
        #         torch.save(L_cosine_similarities, file_path1)
        #         print("Cosine similarities computed and saved.")
        # else:
        #     print("Not continuing from file. Computing cosine similarities...")
        #     L_cosine_similarities = compute_cosine_similarities(all_L_prompt_embeds)
        #     torch.save(L_cosine_similarities, file_path1)
        #     print("Cosine similarities computed and saved.")
        # L_cosine_similarities.to('cpu')

        # if continue_run:
        #     file_path2 = f'{distance_dir}euclidean_distances.pt'
        #     try:
        #         L_euclidean_distances = torch.load(file_path2)
        #         print("Loaded L_euclidean_distances  from file.")
        #     except FileNotFoundError:
        #         print("File not found. Computing L_euclidean_distances ...")
        #         L_euclidean_distances = batched_torch_distance_matrix(all_L_prompt_embeds, 'euclidean', batch_size)
        #         torch.save(L_euclidean_distances, file_path2)
        #         print("Cosine  computed and saved.")
        # else:
        #     print("Not continuing from file. Computing L_euclidean_distances ...")
        #     L_euclidean_distances = batched_torch_distance_matrix(all_L_prompt_embeds, 'euclidean', batch_size)
        #     torch.save(L_euclidean_distances, file_path2)
        #     print("L_euclidean_distances  computed and saved.")
        # L_euclidean_distances.to('cpu')
        
        # if continue_run:
        #     file_path3 = f'{distance_dir}manhattan_distances.pt'
        #     try:
        #         L_manhattan_distances = torch.load(file_path3)
        #         print("Loaded L_manhattan_distances  from file.")
        #     except FileNotFoundError:
        #         print("File not found. Computing L_manhattan_distances ...")
        #         L_manhattan_distances = batched_torch_distance_matrix(all_L_prompt_embeds, 'euclidean', batch_size)
        #         torch.save(L_manhattan_distances, file_path3)
        #         print("Cosine  computed and saved.")
        # else:
        #     print("Not continuing from file. Computing L_manhattan_distances ...")
        #     L_manhattan_distances = batched_torch_distance_matrix(all_L_prompt_embeds, 'manhattan', batch_size)
        #     torch.save(L_manhattan_distances, file_path3)
        #     print("L_manhattan_distances  computed and saved.")

        # Store results
        model_name = os.path.basename(model_path)
        # index_labels = list(text_dict.values())
        # results["Cosine"][model_name] = pd.DataFrame(L_cosine_similarities.cpu().numpy(), index=index_labels, columns=index_labels)
        # results["Euclidean"][model_name] = pd.DataFrame(L_euclidean_distances, index=index_labels, columns=index_labels)
        # results["Manhattan"][model_name] = pd.DataFrame(L_manhattan_distances, index=index_labels, columns=index_labels)
        # results['Embeddings'][model_name] = all_L_prompt_embeds
        results['Embeddings_L'][model_name] = all_L_prompt_embeds

    return results


def print_results(results, decimals=3):
    for distance_type, models in results.items():
        print(f"{distance_type} Distances:")
        for model_name, df in models.items():
            print(f"\nModel: {model_name}")
            # if distance_type == "Lengths":
            #     # Print all lengths in one row, formatted to the specified number of decimal places
            #     lengths_formatted = ", ".join(f"{key}: {val:.{decimals}f}" for key, val in zip(text.keys(), df))
            #     print(lengths_formatted)
            # else:
            # Format the dataframe to display distances with the specified number of decimal digits
            formatted_df = df.round(decimals)
            print(formatted_df)
        print("\n" + "-"*40)

def visualize_embeddings_with_plotly(embeddings_dict, text_dict, markers_dict, id_to_category, category_colors, clip='L', method='tsne', distance_dir=None, n_components=2, random_state=42, continue_run=False):
    # Initialize Plotly figure
    fig = go.Figure()

    # Iterate through each model and its embeddings
    for model_name, embeddings in embeddings_dict.items():
        # Use GPU if available for the initial tensor operations
        if torch.cuda.is_available():
            embeddings = embeddings.to('cuda')
        
        # Dimensionality reduction
        if method == 'tsne':
            file_path_tsne = os.path.join(distance_dir, f'{clip}_tsne.pt')
            if continue_run:
                try:
                    embeddings_reduced = torch.load(file_path_tsne).cpu().numpy()
                except FileNotFoundError:
                    embeddings_reduced = TSNE(n_components=n_components, perplexity=min(len(embeddings)-1, 30), random_state=random_state).fit_transform(embeddings.cpu().numpy())
                    torch.save(torch.tensor(embeddings_reduced), file_path_tsne)
            else:
                embeddings_reduced = TSNE(n_components=n_components, perplexity=min(len(embeddings)-1, 30), random_state=random_state).fit_transform(embeddings.cpu().numpy())
                torch.save(torch.tensor(embeddings_reduced), file_path_tsne)
                
        elif method == 'umap':
            file_path_umap = os.path.join(distance_dir, f'{clip}_umap.pt')
            if continue_run:
                try:
                    embeddings_reduced = torch.load(file_path_umap).cpu().numpy()
                except FileNotFoundError:
                    reducer = umap.UMAP(n_components=n_components, random_state=random_state)
                    embeddings_reduced = reducer.fit_transform(embeddings.cpu().numpy())
                    torch.save(torch.tensor(embeddings_reduced), file_path_umap)
            else:
                reducer = umap.UMAP(n_components=n_components, random_state=random_state)
                embeddings_reduced = reducer.fit_transform(embeddings.cpu().numpy())
                torch.save(torch.tensor(embeddings_reduced), file_path_umap)

        elif method == 'pca':
            file_path_pca =  os.path.join(distance_dir, f'{clip}_pca.pt')
            if continue_run:
                try:
                    embeddings_reduced = torch.load(file_path_pca)
                except FileNotFoundError:
                    embeddings_reduced = PCA(n_components=n_components, random_state=random_state).fit_transform(embeddings.cpu().numpy())
                    torch.save(torch.tensor(embeddings_reduced), file_path_pca)
            else:
                embeddings_reduced = PCA(n_components=n_components, random_state=random_state).fit_transform(embeddings.cpu().numpy())
                torch.save(torch.tensor(embeddings_reduced), file_path_pca)
        else:
            raise ValueError("Method must be 'tsne' or 'pca' or 'umap'")

        # Add traces for each point in the reduced dimension plot
        for i, (label, value) in enumerate(text_dict.items()):
            category = id_to_category.get(str(value), '99')
            color = category_colors[category]
            text = text_dict[str(label)]
            marker = markers_dict.get(label, 'circle')
            fig.add_trace(go.Scattergl(
                x=[embeddings_reduced[i, 0]],
                y=[embeddings_reduced[i, 1]],
                mode='markers',
                marker=dict(symbol=marker, size=8, color=color),
                name=text,
                hoverinfo='text'
            ))
            
    fig.update_layout(
        title=f'{method.upper()} Visualization of {model_name} - {clip} - {method}',
        xaxis_title=f'{method.upper()} 1',
        yaxis_title=f'{method.upper()} 2',
        legend_title="Dictionary"
    )
    
    if method == 'tsne':
        file_path_pca2 =  os.path.join(distance_dir, f'{clip}_tsne_plot.html')
        fig.write_html(file_path_pca2)
    elif method == 'pca':
        file_path_pca2 =  os.path.join(distance_dir, f'{clip}_pca_plot.html')
        fig.write_html(file_path_pca2)
    elif method == 'umap':
        file_path_pca2 =  os.path.join(distance_dir, f'{clip}_umap_plot.html')
        fig.write_html(file_path_pca2)

def main(model_type, continue_run, model_file, output_dir, graph_type):
    device = "cuda"
    embedding_names = 'names.json'
    embedding_markers = 'markers.json'
    embed_groupings = 'named_cluster_dict.json'
    category_colors, id_to_category = config_to_category_colors(embed_groupings)

    with open(embedding_names, 'r') as jfile:
        text_dict = json.load(jfile)
        
    with open(embedding_markers, 'r') as json_file:
        markers_dict = json.load(json_file)

    model_paths = [model_file]

    with torch.no_grad():
        if model_type == 'sdxl':
            results = compute_distances_sdxl(model_paths, text_dict, output_dir, device, continue_run)
        elif model_type == 'sd15':
            results = compute_distances_sd15(model_paths, text_dict, output_dir, device, continue_run)
        elif model_type == 'clip':
            results = compute_distances_clip(model_paths, text_dict, output_dir, device, continue_run)
        
    for model_path in model_paths:
        model_name = os.path.basename(model_path)
        distance_dir = os.path.join(output_dir, 'distances', model_name)
        if not os.path.exists(distance_dir):
            os.makedirs(distance_dir)
            
        if model_type == 'sdxl':
            if graph_type == 'all':
                visualize_embeddings_with_plotly(results['Embeddings_L'], text_dict, markers_dict, id_to_category, category_colors, clip='L', method='pca', distance_dir=distance_dir, continue_run=continue_run)
                visualize_embeddings_with_plotly(results['Embeddings_L'], text_dict, markers_dict, id_to_category, category_colors, clip='L', method='tsne', distance_dir=distance_dir, continue_run=continue_run)
                visualize_embeddings_with_plotly(results['Embeddings_L'], text_dict, markers_dict, id_to_category, category_colors, clip='L', method='umap', distance_dir=distance_dir, continue_run=continue_run)
                visualize_embeddings_with_plotly(results['Embeddings_G'], text_dict, markers_dict, id_to_category, category_colors, clip='G', method='pca', distance_dir=distance_dir, continue_run=continue_run)
                visualize_embeddings_with_plotly(results['Embeddings_G'], text_dict, markers_dict, id_to_category, category_colors, clip='G', method='tsne', distance_dir=distance_dir, continue_run=continue_run)
                visualize_embeddings_with_plotly(results['Embeddings_G'], text_dict, markers_dict, id_to_category, category_colors, clip='G', method='umap', distance_dir=distance_dir, continue_run=continue_run)
            elif graph_type == 'pca':
                visualize_embeddings_with_plotly(results['Embeddings_L'], text_dict, markers_dict, id_to_category, category_colors, clip='L', method='pca', distance_dir=distance_dir, continue_run=continue_run)
                visualize_embeddings_with_plotly(results['Embeddings_G'], text_dict, markers_dict, id_to_category, category_colors, clip='G', method='pca', distance_dir=distance_dir, continue_run=continue_run)
            elif graph_type == 'tsne':
                visualize_embeddings_with_plotly(results['Embeddings_L'], text_dict, markers_dict, id_to_category, category_colors, clip='L', method='tsne', distance_dir=distance_dir, continue_run=continue_run)
                visualize_embeddings_with_plotly(results['Embeddings_G'], text_dict, markers_dict, id_to_category, category_colors, clip='G', method='tsne', distance_dir=distance_dir, continue_run=continue_run)
            elif graph_type == 'umap':
                visualize_embeddings_with_plotly(results['Embeddings_L'], text_dict, markers_dict, id_to_category, category_colors, clip='L', method='umap', distance_dir=distance_dir, continue_run=continue_run)
                visualize_embeddings_with_plotly(results['Embeddings_G'], text_dict, markers_dict, id_to_category, category_colors, clip='G', method='umap', distance_dir=distance_dir, continue_run=continue_run)
            elif graph_type == 'L':
                visualize_embeddings_with_plotly(results['Embeddings_L'], text_dict, markers_dict, id_to_category, category_colors, clip='L', method='pca', distance_dir=distance_dir, continue_run=continue_run)
                visualize_embeddings_with_plotly(results['Embeddings_L'], text_dict, markers_dict, id_to_category, category_colors, clip='L', method='tsne', distance_dir=distance_dir, continue_run=continue_run)
                visualize_embeddings_with_plotly(results['Embeddings_L'], text_dict, markers_dict, id_to_category, category_colors, clip='L', method='umap', distance_dir=distance_dir, continue_run=continue_run)
            elif graph_type == 'G':
                visualize_embeddings_with_plotly(results['Embeddings_G'], text_dict, markers_dict, id_to_category, category_colors, clip='G', method='pca', distance_dir=distance_dir, continue_run=continue_run)
                visualize_embeddings_with_plotly(results['Embeddings_G'], text_dict, markers_dict, id_to_category, category_colors, clip='G', method='tsne', distance_dir=distance_dir, continue_run=continue_run)
                visualize_embeddings_with_plotly(results['Embeddings_G'], text_dict, markers_dict, id_to_category, category_colors, clip='G', method='umap', distance_dir=distance_dir, continue_run=continue_run)
        elif model_type == 'sd15':
            if graph_type == 'all' or graph_type == 'G' or graph_type == 'L':
                visualize_embeddings_with_plotly(results['Embeddings_L'], text_dict, markers_dict, id_to_category, category_colors, clip='L', method='pca', distance_dir=distance_dir, continue_run=continue_run)
                visualize_embeddings_with_plotly(results['Embeddings_L'], text_dict, markers_dict, id_to_category, category_colors, clip='L', method='tsne', distance_dir=distance_dir, continue_run=continue_run)
                visualize_embeddings_with_plotly(results['Embeddings_L'], text_dict, markers_dict, id_to_category, category_colors, clip='L', method='umap', distance_dir=distance_dir, continue_run=continue_run)
            elif graph_type == 'pca':
                visualize_embeddings_with_plotly(results['Embeddings_L'], text_dict, markers_dict, id_to_category, category_colors, clip='L', method='pca', distance_dir=distance_dir, continue_run=continue_run)
            elif graph_type == 'tsne':
                visualize_embeddings_with_plotly(results['Embeddings_L'], text_dict, markers_dict, id_to_category, category_colors, clip='L', method='tsne', distance_dir=distance_dir, continue_run=continue_run)
            elif graph_type == 'umap':
                visualize_embeddings_with_plotly(results['Embeddings_L'], text_dict, markers_dict, id_to_category, category_colors, clip='L', method='umap', distance_dir=distance_dir, continue_run=continue_run)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Process some integers.")
    parser.add_argument('--model_type', type=str, required=True, default='sdxl', help='Pick from (sd15, sdxl)')
    parser.add_argument('--continue', dest='continue_run', action='store_true', help='Continue from the last saved state')
    parser.add_argument('--model_file', type=str, required=True, help='Path to the target model')
    parser.add_argument('--output_dir', type=str, required=True, help='Path of the output plot files')
    parser.add_argument('--graph_type', type=str, default='all', help='Pick from (all, pca, tsne, umap, L, G)')
    args = parser.parse_args()
    main(args.model_type, args.continue_run, args.model_file, args.output_dir, args.graph_type)
    
#  python .\clip_graph_xl.py --model_type=sd15 --output_dir=. --continue --model_file="H:\StableDiffusionModels\cyberrealistic_v42.safetensors"